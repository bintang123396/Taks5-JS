alert("Hello World!");
// document.write("<h1>Saya Bintang Rudianto</h1>");
// document.write("<hr>");
// document.write("<p>Saya sedang belajar Javascript</p>");
// document.write("di <b>petanikode.com</b>")

//===========================================

var nama = prompt("Siapa nama kamu?","");
document.write("<p>Hello "+ nama +"</p>");
